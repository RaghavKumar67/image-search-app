import axios from "axios";

const searchImage = async (term) => {
  try {
    const response = await axios.get("https://api.unsplash.com/search/photos", {
      headers: {
        Authorization: "Client-ID cebOoQMsC2hRcuMqYB24bqUk4ZRoS7w3qFBTvuNV_RY", // ✅ TEMP working key
      },
      params: {
        query: term,
      },
    });

    console.log("✅ API Success:", response.data); // 👈 You MUST see this
    return response.data.results; // ✅ Must return this
  } catch (error) {
    console.error("❌ API Error:", error.message);
    return [];
  }
};

export default searchImage;
